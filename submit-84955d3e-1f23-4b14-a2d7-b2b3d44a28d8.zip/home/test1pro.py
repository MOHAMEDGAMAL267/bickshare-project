import time
import pandas as pd
import numpy as np

CITY_DATA = { 'c': 'chicago.csv',
              'n': 'new_york_city.csv',
              'w': 'washington.csv' }
#------------------------------------------------------------------------------------------------------#

def get_filters():
    print('Hello! Let\'s explore some US bikeshare data!')
    
    city = input(" to view bikeshare data , please inter in lower case : \n the letter (c) for chicago \n the letter (n) for new            york \n the letter (w) for washington ").lower()
    while city not in ['c' , 'n' , 'w'] :
        print ("oops sory! you intered invalid letter, please try again.  ")
        city = input(" to view bikeshare data , please inter : \n the letter (c) for chicago \n the letter (n) for new york \n the letter (w) for washington ").lower()
    

    months = ['january' , 'february' , 'march' , 'april' , 'may' , 'june' , 'all' ]
    month = input("please inter a month from january to june or type (all) for not filtering ").lower()
    while month not in months:
        print ("oops sory! something went wrong , please try again. ")
        month = input("please inter a month from january to june or type (all) for not filtering").lower()
     
    days = ['saturday' , 'sunday' , 'monday' , 'tuesday' , 'wednesday' , 'thursday' , 'friday' , 'all']
    day = input ("please inter a day of the week or type (all) for not filtering ")
    while day not in days :
        print ("oops sorry! something went wrong , please try again. ")
        day = input ("please inter a day of the week or type (all) for not filtering ").lower()
    print('-'*40)
    return city,month,day
#------------------------------------------------------------------------------------------------------#

def load_data(city, month, day):
    
    df = pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df ['Start Time'].dt.month
    df['day_of_week'] = df ['Start Time'].dt.weekday_name
    
    if month != 'all':
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month) + 1
        df = df[df['month'] == month]

    if day != 'all':
        df = df[df['day_of_week'] == day.title()]
        
    return df  
#------------------------------------------------------------------------------------------------------#
def time_stats(df):
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()
    # TO DO: display the most common month
    common_month = df['month'].mode()[0]
    print("the most common month is :" , common_month)
    # TO DO: display the most common day of week
    common_day = df['day_of_week'].mode()[0]
    print("the most common day is :" , common_day)
    # TO DO: display the most common start hour
    df['hour'] = df['Start Time'].dt.hour
    common_hour = df['hour'].mode()[0]
    print("the most common hour is :" , common_hour)
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
#------------------------------------------------------------------------------------------------------#
def station_stats(df):
    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()
    # TO DO: display most commonly used start station
    common_start_station = df['Start Station'].mode()[0]
    print ("the most commonly used start station is : " ,common_start_station )
    # TO DO: display most commonly used end station
    common_end_station = df['End Station'].mode()[0]
    print ("the most commonly used end station is : " ,common_end_station )
    # TO DO: display most frequent combination of start station and end station trip
    common_combination = df[['Start Station' , 'End Station']].mode().loc[0]
    print ("the most frequent combination of start station and end station trip is {} ,{}".format(common_combination[0],common_combination[1]))
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
#------------------------------------------------------------------------------------------------------#
def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    total_travel = df['Trip Duration'].sum()
    print("total travel time is : ",total_travel)
    # TO DO: display mean travel time
    mean_travel = df['Trip Duration'].mean()
    print("mean travel time is : ",mean_travel)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
#------------------------------------------------------------------------------------------------------#
    
def user_stats(df):
    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    counts_user_type = df['User Type'].value_counts()
    print("counts of user type is : " ,counts_user_type )
    # TO DO: Display counts of gender
    while 'Gender' in df.columns:
        user_gender(df)
    # TO DO: Display earliest, most recent, and most common year of birth
    while 'Birth Year' in df.columns:
        user_birth(df)
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
#------------------------------------------------------------------------------------------------------#

def user_gender(df):
    gender_counts = df['Gender'].value_counts()
   
def user_birth(df):
    earliest_user = df['Birth Year'].min()
    print("the earliest user born in : " , earliest_user)
    
    most_recent = df['Birth Year'].max()
    print("the most recent user born in : " , most_recent)
    
    most_common = df['Birth Year'].mode()
    print("the most common birth year is : " , most_common)
#------------------------------------------------------------------------------------------------------#


def main():
    while True:
        
        city, month, day = get_filters()
        df = load_data(city, month, day)
        time_stats(df)    
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        
        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break

if __name__ == "__main__":
	main()
